module tb;
reg [3:0]a1,a2,add1,add2;
reg clk,rst,en1,en2;
wire [3:0]d1,d2;
ram dx(.clk(clk),.rst(rst),.add1(add1),.add2(add2),.a1(a1),.a2(a2),.en1(en1),.en2(en2),.d1(d1),.d2(d2));
initial begin
clk=0;
rst=1;
#10
rst=0;
en1=1; en2=1;
a1=4'b1100;
add1=4'b0001;
a2=4'b0011;
add2=4'b0010;
#10
en1=0; en2=0;
add1=4'b0001;
add2=4'b0010;#10;
end
always #5 clk=~clk;
initial begin
$monitor("clk:%b,rst:%b,a1:%b,a2:%b,add1:%b,add2:%b,en1:%b,en2:%b,d1:%b,d2:%b",clk,rst,a1,a2,add1,add2,en1,en2,d1,d2);
#150 $stop();
end
endmodule
