vlog dut.v tb.v
vsim tb
run -all
