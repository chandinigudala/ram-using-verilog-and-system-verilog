module ram(
input [3:0]a1,a2,add1,add2,
input clk,rst,en1,en2,
output reg [3:0]d1,d2
);
reg [3:0]mem[15:0];
integer i;
always @(posedge clk) begin
if(rst==1) begin
    d1<=4'b0000;
    d2<=4'b0000;
    for(i=0; i<16; i=i+1)
        mem[i]<=4'b0000;
        end
        else begin
            if(en1==1 && en2==1) begin
                mem[add1]<=a1;
                 mem[add2]<=a2;

                end
               
                    else if(en1==0 && en2==0 ) begin
                        d1<=mem[add1];
                        d2<=mem[add2];

                        end
                       
                            end
                            end
                            endmodule

