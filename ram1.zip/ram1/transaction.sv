class transaction;
bit [3:0]din;
bit [3:0]add;
bit clk,rst,rd,wd;
bit [3:0]dout;
function void display(string s="from transaction");
$display("%s clk:%b,rst:%b,rd:%b,wd:%b,add:%d,din:%d,dout:%d",s,clk,rst,rd,wd,add,din,dout);
endfunction
endclass
