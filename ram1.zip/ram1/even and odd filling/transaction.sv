class transaction;
bit [7:0]din;
bit [5:0]add;
bit clk,rst,rd,wd;
bit [7:0]dout;
constraint name {add<20;}
constraint name1 {din<30;}
/*constraint name {if(add%2==0) 
din==10*add;
else
    din==add*3;}*/
function void display(string s="from transaction");
$display("%s clk:%b,rst:%b,rd:%b,wd:%b,add:%d,din:%d,dout:%d",s,clk,rst,rd,wd,add,din,dout);
endfunction
endclass
