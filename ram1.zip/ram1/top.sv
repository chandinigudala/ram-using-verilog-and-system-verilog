`include "dut.sv"
`include "interface.sv"
`include "transaction.sv"
`include "generator.sv"
`include "driver.sv"
`include "inputmonitor.sv"
`include "outputmonitor.sv"
`include "scoreboard.sv"
`include "env.sv"
`include "test.sv"
`include "program.sv"
module top();
reg clk,rst;
interface_ram inter(.clk(clk),.rst(rst));
dut a1(.clk(inter.clk),.rst(inter.rst),.rd(inter.rd),.wd(inter.wd),.add(inter.add),.din(inter.din),.dout(inter.dout));
tb a2(inter);
initial begin
clk=0;
rst=1;
#10
rst=0;
/*rd=1;
wd=0;
#100;
rd=0;
wd=1;*/
end
always #5 clk=!clk;
initial begin
#70 $finish();
end
endmodule





