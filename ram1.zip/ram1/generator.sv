class generator;
transaction tr;
mailbox #(transaction) g2d;
function new(input mailbox #(transaction) g2d);
this.g2d=g2d;
endfunction
task run();
#1;
tr=new();
send();
#10;
receive();
endtask
task send();
tr.rd=0; tr.wd=1;
for(int i=0; i<=15; i++) begin
    tr.add=i;
    tr.din=i*2;
    g2d.put(tr);
#10;
    end
    endtask
    task receive();
    tr.rd=1; tr.wd=0;
    for(int j=0; j<=15; j++) begin
        tr.add=j;
        g2d.put(tr);
#10;
        end
        endtask
        task tc1();      //1 write 1 read
#1;
        tr=new();
        tr.wd=1; tr.rd=0;
        tr.add=4'b0010;
        tr.din=4'b0001;
        g2d.put(tr);
#10;
#10;
        tr.wd=0; tr.rd=1;
        tr.add=4'b0010;
        g2d.put(tr);
#10;
        endtask
        task tc2();        //overlapping address
#1;
        tr=new();
        tr.wd=1; tr.rd=0;
        tr.add=4'b0010;
        tr.din=4'b0001;
        tr.add=4'b0010;
        tr.din=4'b1000;
        g2d.put(tr);
#10;
#10;
        tr.wd=0; tr.rd=1;
        tr.add=4'b0010;
        g2d.put(tr);
#10;
        endtask
        task tc3();        //reading without writing
        #1;
        tr=new();
         tr.wd=0; tr.rd=1;
        tr.add=4'b0010;
        g2d.put(tr);
#10;
        endtask
        task tc4();         //reset
#1;
        tr=new();
        tr.wd=1; tr.rd=0;
        tr.add=4'b0010;
        tr.din=4'b0001;
        g2d.put(tr);
#10;
        tr.rst=1;
        g2d.put(tr);
#10;
        tr.rst=0;
         tr.wd=0; tr.rd=1;
        tr.add=4'b0010;
        g2d.put(tr);
#10;
        endtask
        task tc5();
#1;
        tr=new();
        tr.wd=1; tr.rd=0;
        for(int i=0; i<=15; i++) begin
            tr.add=i;
            tr.din=i;
            g2d.put(tr);
#10;
            end
            endtask
            task tc6();
#1;
            tr=new();
            tr.add=$urandam_range(5,15);
            tr.din=$urandam_range(0,15);
            g2d.put(tr);
#30;
            endtask





















 

endclass


