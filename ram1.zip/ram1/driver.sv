class driver;
transaction tr;
mailbox #(transaction) g2d;
virtual interface_ram inter;
function new(input mailbox #(transaction) g2d,virtual interface_ram inter);
this.g2d=g2d;
this.inter=inter;
endfunction
task run();
tr=new();
forever begin
wait(tr.rst==0) begin
g2d.get(tr);
tr.display("from driver");
inter.din=tr.din;
inter.rd  <= tr.rd;
inter.wd  <= tr.wd;
inter.add <= tr.add;
//inter.din <= tr.din;

$display("*********************din:%d*****************",inter.din);
end
end
endtask
endclass
