vlog top.sv +acc
vsim top
add wave *
run -all
