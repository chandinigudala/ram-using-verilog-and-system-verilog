program tb(interface_ram inter);
test t;
initial begin
t=new(inter);
t.run();
end
endprogram

