interface interface_ram(input clk,rst);
logic rd,wd;
logic [3:0]din,add;
logic [3:0]dout;
endinterface
