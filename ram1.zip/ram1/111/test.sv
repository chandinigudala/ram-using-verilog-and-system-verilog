class test;
env e;
virtual interface_ram inter;
function new(input virtual interface_ram inter);
this.inter=inter;
endfunction
task run();
e=new(inter);
e.run();
endtask
endclass

