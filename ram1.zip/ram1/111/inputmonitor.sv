class inputmonitor;
transaction tr;
reg [3:0]mem[15:0];
mailbox #(transaction) i2s;
virtual interface_ram inter;
function new(input mailbox #(transaction) i2s,virtual interface_ram inter);
this.i2s=i2s;
this.inter=inter;
endfunction
task run();
tr=new();
forever begin
@(posedge inter.clk)
tr.din=inter.din;
tr.clk=inter.clk;
tr.rst=inter.rst;
tr.rd=inter.rd;
tr.wd=inter.wd;
tr.add=inter.add;
tr.display("from inputmonitor");
i2s.put(tr);
bfm();
$display("************rd:%b,wd:%b,add:%d,din:%d,dout:%d************************",tr.rd,tr.wd,tr.add,tr.din,tr.dout);
end
endtask
task bfm();
//reg [3:0]mem[15:0];
if(tr.rst==1) begin
    tr.dout=0;
    for(int i=0;i<=15;i++)
        mem[i]=0;
      end
        else begin
            if(tr.rd==0 && tr.wd==1)
                mem[tr.add]=tr.din;
                else if(tr.rd==1 && tr.wd==0)
                    tr.dout=mem[tr.add];
                    else if(tr.rd==1 && tr.wd==1) begin
                        mem[tr.add]=tr.din;
                        tr.dout=mem[tr.add];
                        end
                  end
                    endtask
                    endclass


