interface interface_ram(input clk,rst);
logic rd,wd;
logic [7:0]din;
logic [5:0]add;
logic [7:0]dout;
endinterface
