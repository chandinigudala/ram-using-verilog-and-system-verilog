module dut(
input clk,rst,rd,wd,
input [7:0]din,
input [5:0]add,
output reg [7:0]dout
);
reg [7:0]mem[63:0];
always @(posedge clk) begin
if(rst==1) begin
    dout<=0;
    for(int i=0;i<=15;i++)
        mem[i]<=0;
        end
        else begin
            if(rd==0 && wd==1)
                mem[add]=din;
                else if(rd==1 && wd==0)
                    dout<=mem[add];
                    else if(rd==1 && wd==1) begin
                         mem[add]=din;
                         dout=mem[add];
                         end
                    end
                    end
                    endmodule

