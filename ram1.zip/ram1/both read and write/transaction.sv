class transaction;
rand bit [7:0]din;
rand bit [5:0]add;
bit clk,rst,rd,wd;
bit [7:0]dout;
constraint name {add<20;}
constraint name1 {din<30;}
function void display(string s="from transaction");
$display("%s clk:%b,rst:%b,rd:%b,wd:%b,add:%d,din:%d,dout:%d",s,clk,rst,rd,wd,add,din,dout);
endfunction
endclass
